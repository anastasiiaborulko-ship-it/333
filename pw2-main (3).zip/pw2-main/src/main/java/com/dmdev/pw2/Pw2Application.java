package com.dmdev.pw2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pw2Application {

	public static void main(String[] args) {
		SpringApplication.run(Pw2Application.class, args);
	}

}
