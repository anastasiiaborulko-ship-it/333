package com.dmdev.pw2.database;

import com.dmdev.pw2.backend.Pw2Application;
import com.dmdev.pw2.backend.database.entity.Role;
import com.dmdev.pw2.backend.database.entity.User;
import com.dmdev.pw2.backend.database.repositories.OrdersRepository;
import com.dmdev.pw2.backend.database.repositories.UserRepository;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

//clear db manually and do tests one by one as otherwise the test will fail due to unique constraint violation
//tried to resolve by adding a clearing method in beforeeach, but didnt work
@SpringBootTest(classes = Pw2Application.class)
class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrdersRepository ordersRepository;

    private User testUser;

    @BeforeEach
    void setUp() {

        testUser = User.builder()
                .email("test@example.com")
                .password("initial123")
                .name("John")
                .surname("Doe")
                .address("Some street, 123")
                .phoneNumber("1234567890")
                .role(Role.USER)
                .build();
        userRepository.save(testUser);
    }

    @Test
    void testUpdateUserProfile() {
        int updated = userRepository.updateUserProfile(
                testUser.getUserId(), "Jane", "Smith"
        );
        assertThat(updated).isEqualTo(1);

        Optional<User> updatedUser = userRepository.findById(testUser.getUserId());
        assertThat(updatedUser).isPresent();
        assertThat(updatedUser.get().getName()).isEqualTo("Jane");
        assertThat(updatedUser.get().getSurname()).isEqualTo("Smith");
    }

    @Test
    void testUpdatePassword() {
        int updated = userRepository.updatePassword(testUser.getUserId(), "newPassword123");
        assertThat(updated).isEqualTo(1);

        Optional<User> updatedUser = userRepository.findById(testUser.getUserId());
        assertThat(updatedUser).isPresent();
        assertThat(updatedUser.get().getPassword()).isEqualTo("newPassword123");
    }

    @Test
    void testUpdateRole() {
        int updated = userRepository.updateRole(testUser.getUserId(), Role.ADMIN);
        assertThat(updated).isEqualTo(1);

        Optional<User> updatedUser = userRepository.findById(testUser.getUserId());
        assertThat(updatedUser).isPresent();
        assertThat(updatedUser.get().getRole()).isEqualTo(Role.ADMIN);
    }

    @Test
    void testFindByPhoneNumber() {
        Optional<User> foundUser = userRepository.findByPhoneNumber("1234567890");
        assertThat(foundUser).isPresent();
        assertThat(foundUser.get().getEmail()).isEqualTo("test@example.com");
    }
}

