package com.dmdev.pw2.backend.service;

import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.*;

@Service
public class ReceiptExportService {

    private final DataSource dataSource;

    public ReceiptExportService(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public File exportReceipt(int orderId) {
        String orderInfoSql = "SELECT order_id, order_date, delivery_date, order_status, total_price " +
                "FROM `orders` WHERE order_id = ?";

        String orderContentsSql = "SELECT p.name, p.colour, op.quantity " +
                "FROM order_product op " +
                "JOIN product p ON op.product_id = p.product_id " +
                "WHERE op.order_id = ?";

        File receiptFile = new File("receipt_order_" + orderId + ".txt");

        try (Connection connection = dataSource.getConnection();
             PreparedStatement orderStmt = connection.prepareStatement(orderInfoSql);
             PreparedStatement productStmt = connection.prepareStatement(orderContentsSql);
             BufferedWriter writer = new BufferedWriter(new FileWriter(receiptFile))) {

            orderStmt.setInt(1, orderId);
            ResultSet orderResultSet = orderStmt.executeQuery();

            if (!orderResultSet.next()) {
                throw new RuntimeException("Orders not found: " + orderId);
            }

            writer.write("=== 'GLEAM' JEWELLERY SHOP RECEIPT ===\n\n");
            writer.write("Thank you for your purchase! Here is your receipt:\n\n");
            writer.write("Orders ID: " + orderResultSet.getInt("order_id") + "\n");
            writer.write("Orders Date: " + orderResultSet.getDate("order_date") + "\n");
            writer.write("Delivery Date: " + orderResultSet.getDate("delivery_date") + "\n");
            writer.write("Status: " + orderResultSet.getString("status") + "\n\n");

            writer.write("Items:\n");

            productStmt.setInt(1, orderId);
            ResultSet productRs = productStmt.executeQuery();

            while (productRs.next()) {
                writer.write(" - " + productRs.getString("name") +
                        " (" + productRs.getString("color") + ")" +
                        " x " + productRs.getInt("quantity") + "\n");
            }

            writer.write("\nFinal Price: " + orderResultSet.getBigDecimal("final_price") + "€\n\n");
            writer.write("=============================\n");

        } catch (Exception e) {
            throw new RuntimeException("Error generating receipt: " + e.getMessage(), e);
        }

        return receiptFile;
    }
}
