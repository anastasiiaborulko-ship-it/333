package com.dmdev.pw2.backend.controllers;

import com.dmdev.pw2.backend.database.entity.Orders;
import com.dmdev.pw2.backend.dto.OrderRequestDTO;
import com.dmdev.pw2.backend.service.OrdersService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class OrdersController {

    @Autowired
    private OrdersService ordersService;

    @PostMapping("/create")
    public Orders createOrder(@RequestBody OrderRequestDTO dto) {
        return ordersService.createOrder(dto);
    }

    @GetMapping("/my")
    public List<Orders> getMyOrders(@RequestParam Long userId) {
        return ordersService.getOrdersForUser(userId);
    }

    @GetMapping("/all")
    public List<Orders> getAllOrders() {
        return ordersService.getAllOrders();
    }

    @PatchMapping("/{orderId}/status")
    public Orders updateOrderStatus(
            @PathVariable Long orderId,
            @RequestParam String status) {
        return ordersService.updateStatus(orderId, status);
    }
}
