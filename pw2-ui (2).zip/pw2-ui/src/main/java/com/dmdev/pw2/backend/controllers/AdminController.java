package com.dmdev.pw2.backend.controllers;

import com.dmdev.pw2.backend.database.entity.Product;
import com.dmdev.pw2.backend.database.repositories.ProductRepository;
import com.dmdev.pw2.backend.database.repositories.UserRepository;
import com.dmdev.pw2.backend.database.repositories.OrdersRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final OrdersRepository ordersRepository;

    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    @GetMapping("/users")
    public Object getAllUsers() {
        return userRepository.findAll();
    }

    @GetMapping("/orders")
    public Object getAllOrders() {
        return ordersRepository.findAll();
    }

    @PostMapping("/products")
    public Product addProduct(@RequestBody Product product) {
        return productRepository.save(product);
    }

    @PutMapping("/products/{id}")
    public Product updateProduct(@PathVariable Long id, @RequestBody Product product) {
        product.setProductId(id);
        return productRepository.save(product);
    }

    @DeleteMapping("/products/{id}")
    public void deleteProduct(@PathVariable Long id) {
        productRepository.deleteById(id);
    }
}
