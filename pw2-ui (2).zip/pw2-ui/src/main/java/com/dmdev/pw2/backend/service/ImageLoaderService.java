package com.dmdev.pw2.backend.service;

import com.dmdev.pw2.backend.database.entity.Product;
import com.dmdev.pw2.backend.database.repositories.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ImageLoaderService implements CommandLineRunner {

    private final ProductRepository productRepository;

    @Override
    public void run(String... args) {
        List<Product> products = productRepository.findAll();

        for (Product product : products) {
            if (product.getImage() == null || product.getImage().isBlank()) {
                String fileName = product.getProductId() + ".jpg";
                product.setImage(fileName);
            }
        }

        productRepository.saveAll(products);

        System.out.println("ImageLoaderService: images assigned (if empty) ✔");
    }
}
