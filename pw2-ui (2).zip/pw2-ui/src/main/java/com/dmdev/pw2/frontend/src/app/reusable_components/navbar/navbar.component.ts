import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../authentication/auth.service';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink, NgIf],
  template: `
<header class="bg-white shadow">
  <nav class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex h-16 items-center justify-between">
    <button class="lg:hidden p-2 text-gray-500" (click)="showMobileMenu = true">
      <span class="sr-only">Open menu</span>
      ☰
    </button>

    <a routerLink="/home"><img src='assets/images/logo.svg' alt='Logo' class='h-12 w-auto'></a>

    <div class="hidden lg:flex gap-8 text-sm font-medium">
      <a routerLink="/home" class="hover:text-gray-900">Home</a>
      <a routerLink="/contact" class="hover:text-gray-900">Contact</a>
      <a *ngIf="authService.isLoggedIn()" routerLink="/order" class="hover:text-gray-900">My Orders</a>
      <a *ngIf="authService.isLoggedIn()" (click)="logout()" class="hover:text-gray-900 cursor-pointer">Logout</a>
      <a *ngIf="!authService.isLoggedIn()" routerLink="/login" class="hover:text-gray-900">Login</a>
    </div>
  </nav>
</header>

<dialog id="mobile-menu" class="lg:hidden w-full p-4" [open]="showMobileMenu">
  <button (click)="showMobileMenu = false" class="mb-4">✕</button>
  <ul class="flex flex-col gap-4 text-base">
    <li><a routerLink="/home" (click)="showMobileMenu = false">Home</a></li>
    <li><a routerLink="/contact" (click)="showMobileMenu = false">Contact</a></li>
    <li *ngIf="authService.isLoggedIn()"><a routerLink="/order" (click)="showMobileMenu = false">My Orders</a></li>
    <li *ngIf="authService.isLoggedIn()"><a (click)="logout(); showMobileMenu = false" class="cursor-pointer">Logout</a></li>
    <li *ngIf="!authService.isLoggedIn()"><a routerLink="/login" (click)="showMobileMenu = false">Login</a></li>
  </ul>
</dialog>
  `,
})
export class NavbarComponent {
  showMobileMenu = false;

  constructor(public authService: AuthService) {}

  logout(): void {
    this.authService.logout().subscribe({
      next: () => {
        localStorage.removeItem('user');
        location.reload(); // reload so router updates
      },
      error: (err) => console.error(err)
    });
  }
}
