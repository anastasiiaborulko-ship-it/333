import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ProductGalleryComponent } from '../products/product-gallery.component/product-gallery.component';
import { ProductModel } from '../products/product.model';
import { NavbarComponent } from '../../reusable_components/navbar/navbar.component';
import { FooterComponent } from '../../reusable_components/footer/footer.component';
import { CommonModule } from '@angular/common';
import { ProductService } from '../products/product.service';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    NavbarComponent,
    FooterComponent,
    ProductGalleryComponent,
    CommonModule,
    RouterLink,
    FormsModule
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {

  products: ProductModel[] = [];
  filteredProducts: ProductModel[] = [];

  searchText = '';
  selectedCategory = '';
  minPrice: number | null = null;
  maxPrice: number | null = null;

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts(): void {
    this.productService.getAllProducts().subscribe({
      next: data => {
        this.products = data;
        this.filteredProducts = data;
      },
      error: err => console.error(err)
    });
  }

  applyFilters(): void {
    this.filteredProducts = this.products.filter(p =>
      (!this.searchText || p.name.toLowerCase().includes(this.searchText.toLowerCase())) &&
      (!this.selectedCategory || p.category === this.selectedCategory) &&
      (!this.minPrice || p.price >= this.minPrice) &&
      (!this.maxPrice || p.price <= this.maxPrice)
    );
  }

  resetFilters(): void {
    this.searchText = '';
    this.selectedCategory = '';
    this.minPrice = null;
    this.maxPrice = null;
    this.filteredProducts = this.products;
  }
}
