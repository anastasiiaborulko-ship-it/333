import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, RouterLink} from '@angular/router';
import {ProductService} from '../product.service';
import {ProductModel} from '../product.model';
import {ProductGalleryComponent} from '../product-gallery.component/product-gallery.component';
import {NavbarComponent} from '../../../reusable_components/navbar/navbar.component';
import {FooterComponent} from '../../../reusable_components/footer/footer.component';
import {CommonModule} from '@angular/common';

@Component({
  selector: 'app-product-details',
  imports: [
    ProductGalleryComponent,
    NavbarComponent,
    FooterComponent,
    RouterLink,
    CommonModule
  ],
  templateUrl: './product-details.component.html',
  styleUrl: './product-details.component.css',
})
export class ProductDetailsComponent implements OnInit {

  product!: ProductModel;
  galleryImages: string[] = [];

  constructor(private route: ActivatedRoute,
              private productService: ProductService) {}

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      const id = Number(params.get('id'));

      //load product
      this.productService.getProductById(id).subscribe(product => {
        this.product = product;
      });

      //load gallery
      this.productService.getProductGallery(id).subscribe(images => {
        this.galleryImages = images;
      });
    });
  }

}
