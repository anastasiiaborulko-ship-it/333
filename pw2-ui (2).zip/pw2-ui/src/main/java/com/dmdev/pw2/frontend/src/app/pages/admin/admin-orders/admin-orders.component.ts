import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import {NgClass} from '@angular/common';

@Component({
  selector: 'app-admin-orders',
  templateUrl: './admin-orders.component.html',
  imports: [
    FormsModule,
    NgClass
  ],
  styleUrls: ['./admin-orders.component.css']
})
export class AdminOrdersComponent {

  orders: any[] = [];
  searchEmail: string = '';
  statusFilter: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadOrders();
  }

  loadOrders(): void {
    this.http.get<any[]>('http://localhost:8080/api/orders')
      .subscribe({
        next: (data) => this.orders = data,
        error: (err) => console.error("Orders loading error:", err)
      });
  }

  filteredOrders() {
    return this.orders.filter(o =>
      (this.searchEmail ? o.user.email.toLowerCase().includes(this.searchEmail.toLowerCase()) : true) &&
      (this.statusFilter ? o.orderStatus === this.statusFilter : true)
    );
  }

  changeStatus(order: any, newStatus: string) {
    this.http.patch(`http://localhost:8080/api/orders/${order.orderId}/status`, { status: newStatus })
      .subscribe({
        next: () => {
          order.orderStatus = newStatus;
        },
        error: err => console.error(err)
      });
  }

  onStatusChange(order: any, event: Event): void {
    const select = event.target as HTMLSelectElement;
    const value = select?.value;
    if (!value) return;

    this.changeStatus(order, value);
  }

  generateReceipt(order: any): void {
    const receiptContent = `
==============================
         ORDER RECEIPT
==============================

Order ID: ${order.orderId}
Customer: ${order.user.email}
Order Date: ${order.orderDate}
Delivery Date: ${order.deliveryDate}
Status: ${order.orderStatus}

Products:
${order.orderProducts.map((p:any) => ` - ${p.product.name} x${p.quantity} = ${p.product.price * p.quantity}€`).join('\n')}

------------------------------
Total Price: ${order.totalPrice} €
==============================
Thanks for your purchase!
`;

    const blob = new Blob([receiptContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `receipt_order_${order.orderId}.txt`;
    a.click();
    window.URL.revokeObjectURL(url);
  }
}
