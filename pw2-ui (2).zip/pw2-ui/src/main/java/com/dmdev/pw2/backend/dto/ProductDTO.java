package com.dmdev.pw2.backend.dto;

import java.math.BigDecimal;

public record ProductDTO(Long productId,
                         String name,
                         BigDecimal price,
                         String image,
                         String category,
                         String colour,
                         String manufacturer) {
}
