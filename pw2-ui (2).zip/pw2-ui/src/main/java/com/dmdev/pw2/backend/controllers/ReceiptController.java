package com.dmdev.pw2.backend.controllers;

import com.dmdev.pw2.backend.service.ReceiptExportService;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;

@RestController
@RequestMapping("/api/orders")
public class ReceiptController {

    private final ReceiptExportService receiptExportService;

    public ReceiptController(ReceiptExportService receiptExportService) {
        this.receiptExportService = receiptExportService;
    }

    @GetMapping("/{orderId}/receipt")
    public ResponseEntity<FileSystemResource> downloadReceipt(@PathVariable int orderId) {

        File file = receiptExportService.exportReceipt(orderId);

        FileSystemResource resource = new FileSystemResource(file);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=" + file.getName())
                .contentType(MediaType.TEXT_PLAIN)
                .body(resource);
    }
}
