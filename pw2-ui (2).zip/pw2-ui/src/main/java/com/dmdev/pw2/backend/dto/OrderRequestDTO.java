package com.dmdev.pw2.backend.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class OrderRequestDTO {

    private Long userId;
    private List<OrderProductDTO> products;

    @Getter
    @Setter
    public static class OrderProductDTO {
        private Long productId;
        private int quantity;
    }
}
