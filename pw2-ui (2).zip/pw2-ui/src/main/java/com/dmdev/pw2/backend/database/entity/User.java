package com.dmdev.pw2.backend.database.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "user")
@Getter
@Setter
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long userId;

    @Column(unique = true, nullable = false)
    private String email;
    private String password;
    private String name;
    private String surname;
    private String address;

    @Column(name = "phone_number", unique = true, nullable = false)
    private String phoneNumber;

    @Enumerated(EnumType.STRING)
    private Role role;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Orders> orders;

    public void addOrder(Orders order) {
        orders.add(order);
        order.setUser(this);
    }

    public void removeOrder(Orders order) {
        orders.remove(order);
        order.setUser(null);
    }

    public Long getId() {
        return userId;
    }
}
