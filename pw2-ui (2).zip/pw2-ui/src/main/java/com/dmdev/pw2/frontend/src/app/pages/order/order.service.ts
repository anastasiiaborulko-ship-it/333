import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface OrderProduct {
  orderProductId: number;
  product: { name: string; price: number; };
  quantity: number;
}

export interface User {
  userId: number;
  email: string;
}

export enum OrderStatus {
  PENDING = 'PENDING',
  PREPARING = 'PREPARING',
  IN_DELIVERY = 'IN_DELIVERY',
  DELIVERED = 'DELIVERED',
  CANCELLED = 'CANCELLED'
}
export interface Order {
  orderId: number;
  user: User;
  totalPrice: number;
  orderStatus: OrderStatus;
  deliveryDate: string;
  orderDate: string;
  orderProducts: OrderProduct[];
}


@Injectable({
  providedIn: 'root'
})
export class OrdersService {

  private apiUrl = 'http://localhost:8080/api/orders';

  constructor(private http: HttpClient) { }

  getMyOrders(userId: number): Observable<Order[]> {
    return this.http.get<Order[]>(`${this.apiUrl}/my?userId=${userId}`);
  }

  getAllOrders(): Observable<Order[]> {
    return this.http.get<Order[]>(this.apiUrl, { withCredentials: true });
  }

  updateOrderStatus(id: number, status: OrderStatus): Observable<any> {
    return this.http.put(
      `http://localhost:8080/api/admin/orders/${id}`,
      { orderStatus: status },
      { withCredentials: true }
    );
  }

}
