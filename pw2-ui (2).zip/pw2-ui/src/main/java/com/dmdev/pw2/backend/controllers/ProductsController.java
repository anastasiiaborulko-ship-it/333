package com.dmdev.pw2.backend.controllers;

import com.dmdev.pw2.backend.database.entity.Product;
import com.dmdev.pw2.backend.database.repositories.ProductRepository;
import com.dmdev.pw2.backend.dto.ProductDTO;
import com.dmdev.pw2.backend.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class ProductsController {

    private final ProductRepository productRepository;
    private final ProductService productService;

    @GetMapping
    public List<ProductDTO> getAllProducts() {
        return productRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .toList();
    }

    @GetMapping("/search")
    public List<ProductDTO> searchProducts(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String colour,
            @RequestParam(required = false) BigDecimal minPrice,
            @RequestParam(required = false) BigDecimal maxPrice,
            @RequestParam(required = false) String manufacturer,
            @RequestParam(required = false) String material,
            @RequestParam(required = false) String category
    ) {
        return productService.compositeSearch(
                        name, colour, minPrice, maxPrice, material, manufacturer, category
                ).stream()
                .map(this::mapToDTO)
                .toList();
    }
    private String emptyToNull(String s) {
        return (s == null || s.trim().isEmpty()) ? null : s;
    }


    private ProductDTO mapToDTO(Product p) {
        return new ProductDTO(
                p.getProductId(),
                p.getName(),
                p.getPrice(),
                "/images/" + p.getImage(), //prepend static path in the response
                p.getCategory(),
                p.getColour(),
                p.getManufacturer());
    }
}
