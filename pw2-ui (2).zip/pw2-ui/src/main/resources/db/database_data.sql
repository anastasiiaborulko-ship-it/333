# -- for updating the table contents fully in case of mistakes
SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE order_product;
TRUNCATE TABLE `orders`;
TRUNCATE TABLE user;
TRUNCATE TABLE product;

SET FOREIGN_KEY_CHECKS = 1;

-- users table
INSERT INTO user (email, password, name, surname, address, phone_number, role)
VALUES
    ('alicesmith1@example.com','pass123','Alice','Smith','5, Darželio g.','+370-111-11111','USER'),
    ('bobjohnson@example.com','pass234','Bob','Johnson','42, Kriaučiūnų g.','+370-222-22222','USER'),
    ('user3@example.com','pass345','Jane','Doe','53, Aukštoji g.','+370-333-33333','USER'),
    ('user4@example.com','pass456','James','Brown','10, Tiesioji g.','+370-444-44444','USER'),
    ('user5@example.com','pass567','Kate','Jones','56, Aukštoji g.','+370-555-55555','USER'),
    ('user6@example.com','pass678','Frank','Baker','10, Lapaučiškių g.','+370-666-66666','USER'),
    ('user7@example.com','pass789','Grace','Davis','8, Zietelos g.','+370-777-77777','USER'),
    ('user8@example.com','$2a$10$oJHWfqDTaIAV7B6impReCeLhQSPSJCQN2NkOr5ghXmIMfxYafvnRO','Hank','Wilson','8A, Žarijų g.','+370-888-88888','USER'),
    ('anastasiia.borulko@example.com','$2a$10$fszsxna/a.FVew7vbqzD/.FSWQlESILLPyKtq/BDmbedotVzSls2i','Anastasiia','Borulko','9, Medelyno g.','+370-999-99999','ADMIN'),
    ('svitlana.hordiienko@gmail.com','$2a$10$yC9HpDrSv4M7HjN5whhi8eSci5LILZRon15617gqbHQNRk07Bnkde','Svitlana','Hordiienko','10A, Bažnyčios g.','+370-000-00000','ADMIN');

-- products table
INSERT INTO product (product_id, name, category, material, colour, image, price, manufacturer)
VALUES
(1, 'Cartier LOVE Ring', 'Ring', '18k Gold', 'Yellow', 'cartier_love_ring.jpg', 1250.00, 'Cartier'),
(2, 'Tiffany T Ring', 'Ring', 'Sterling Silver', 'White', 'tiffany_t_ring.jpg', 350.00, 'Tiffany & Co.'),
(3, 'Bvlgari Serpenti Necklace', 'Necklace', '18k Rose Gold', 'Rose', 'bvlgari_serpenti_necklace.jpg', 4800.00, 'Bvlgari'),
(4, 'Tiffany Heart Necklace', 'Necklace', '925 Silver', 'White', 'tiffany_heart_necklace.jpg', 180.00, 'Tiffany & Co.'),
(5, 'Cartier LOVE Bracelet', 'Bracelet', '18k Yellow Gold', 'Yellow', 'cartier_love_bracelet.jpg', 6800.00, 'Cartier'),
(6, 'Pandora Charm Bracelet', 'Bracelet', 'Sterling Silver', 'White', 'pandora_charm_bracelet.jpg', 95.00, 'Pandora'),
(7, 'Chopard Diamond Earrings', 'Earrings', '18k White Gold', 'White', 'chopard_earrings.jpg', 2400.00, 'Chopard'),
(8, 'Tiffany O Earrings', 'Earrings', 'Sterling Silver', 'White', 'tiffany_oearrings.jpg', 250.00, 'Tiffany & Co.'),
(9, 'Bvlgari B.zero1 Pendant', 'Pendant', '18k Rose Gold', 'Rose', 'bvlgari_bzero1_pendant.jpg', 2100.00, 'Bvlgari'),
(10,'Pandora Heart Pendant', 'Pendant', '925 Silver', 'White', 'pandora_heart_pendant.jpg', 85.00, 'Pandora');

-- orders table
INSERT INTO `orders` (user_id, total_price, order_date, delivery_date, order_status)
VALUES (1, 7150.00, '2025-11-15', '2025-11-20', 'DELIVERED'),
       (2, 4800.00, '2025-11-20', '2025-11-25', 'PREPARING'),
       (3, 190.00, '2025-11-25', '2025-11-30', 'IN_DELIVERY'),
       (4, 3650.00, '2025-11-28', '2025-12-03', 'PENDING'),
       (5, 180.00, '2025-12-01', '2025-12-06', 'PREPARING'),
       (1, 2100.00, '2025-12-01', '2025-12-06', 'PENDING'),
       (6, 250.00, '2025-12-02', '2025-12-07', 'PREPARING'),
       (7, 170.00, '2025-12-02', '2025-12-07', 'DELIVERED'),
       (8, 1345.00, '2025-12-03', '2025-12-08', 'PENDING'),
       (2, 5150.00, '2025-12-03', '2025-12-08', 'PREPARING');

-- orderproduct table
INSERT INTO order_product (order_id, product_id, quantity)
VALUES
(1, 5, 1),
(1, 2, 1),

(2, 3, 1),

(3, 6, 2),

(4, 7, 1),
(4, 1, 1),

(5, 4, 1),

(6, 9, 1),

(7, 8, 1),

(8, 10, 2),

(9, 1, 1),
(9, 6, 1),

(10, 3, 1),
(10, 2, 1);
