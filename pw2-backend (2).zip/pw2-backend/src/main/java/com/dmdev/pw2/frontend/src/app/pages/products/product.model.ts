export interface ProductModel {
  productId: number;
  name: string;
  category: string;
  material: string;
  colour: string;
  image: string;
  price: number;
  manufacturer: string;
}
