import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [RouterLink],
  template: `
    <footer class="bg-[#f5d67b] text-[#5a4a42] py-6">
      <div class="max-w-6xl mx-auto px-4 flex flex-col md:flex-row justify-center items-center gap-4">
        <p class="text-sm text-center">&copy; 2025 Gleam. All rights reserved. By <a href="mailto:svitlana.hordiienko@knf.stud.vu.lt">Svitlana Hordiienko</a> and <a href="mailto:anastasiia.borulko@knf.stud.vu.lt">Anastasiia Borulko</a>, ISCS 2nd year, 1st subgroup eng.</p>
      </div>
    </footer>
  `
})
export class FooterComponent {}
