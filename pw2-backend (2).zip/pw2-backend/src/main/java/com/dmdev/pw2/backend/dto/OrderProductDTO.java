package com.dmdev.pw2.backend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
public class OrderProductDTO {
    private Long orderProductId;
    private int quantity;
    private ProductInfo product;

    @Data
    @AllArgsConstructor
    public static class ProductInfo {
        private Long productId;
        private String name;
        private BigDecimal price;
    }
}
