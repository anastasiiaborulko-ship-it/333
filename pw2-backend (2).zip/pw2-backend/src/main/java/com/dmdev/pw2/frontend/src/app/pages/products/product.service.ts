import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import { Observable } from 'rxjs';
import {ProductModel} from './product.model';

@Injectable({ providedIn: 'root' })
export class ProductService {

  private apiUrl = 'http://localhost:8080/api/products';

  constructor(private http: HttpClient) {}

  getAllProducts(): Observable<ProductModel[]> {
    return this.http.get<ProductModel[]>(this.apiUrl, { withCredentials: true });
  }

  getProductById(id: number): Observable<ProductModel> {
    return this.http.get<ProductModel>(`${this.apiUrl}/${id}`, { withCredentials: true });
  }

  searchProducts(filters: {
    name?: string;
    category?: string;
    colour?: string;
    material?: string;
    manufacturer?: string;
    maxPrice?: number;
  }): Observable<ProductModel[]> {
    let params = new HttpParams();

    if (filters.name) params = params.set('name', filters.name);
    if (filters.category) params = params.set('category', filters.category);
    if (filters.colour) params = params.set('colour', filters.colour);
    if (filters.material) params = params.set('material', filters.material);
    if (filters.manufacturer) params = params.set('manufacturer', filters.manufacturer);
    if (filters.maxPrice != null) params = params.set('maxPrice', filters.maxPrice);

    return this.http.get<ProductModel[]>(`${this.apiUrl}/search`, {
      params,
      withCredentials: true
    });
  }

  getProductsByCategory(category: string): Observable<ProductModel[]> {
    return this.http.get<ProductModel[]>(`${this.apiUrl}/search?category=${encodeURIComponent(category)}`, { withCredentials: true });
  }

  getProductGallery(id: number): Observable<string[]> {
    return this.http.get<string[]>(`${this.apiUrl}/${id}/gallery`, { withCredentials: true });
  }
}
