package com.dmdev.pw2.backend.service;

import com.dmdev.pw2.backend.database.entity.Product;
import com.dmdev.pw2.backend.database.repositories.ProductRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(Long id){
        return productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    public Product addProduct(Product product){
        return productRepository.save(product);
    }

    public Product updateProduct(Long id, Product updated){
        Product existing = getProductById(id);

        existing.setName(updated.getName());
        existing.setCategory(updated.getCategory());
        existing.setColour(updated.getColour());
        existing.setMaterial(updated.getMaterial());
        existing.setImage(updated.getImage());
        existing.setManufacturer(updated.getManufacturer());
        existing.setPrice(updated.getPrice());

        return productRepository.save(existing);
    }

    public void deleteProduct(Long id){
        productRepository.deleteById(id);
    }

    public List<Product> compositeSearch(
            String name,
            String colour,
            BigDecimal minPrice,
            BigDecimal maxPrice,
            String material,
            String manufacturer,
            String category
    ) {
        return productRepository.searchProducts(
                name, colour, minPrice, maxPrice, material, manufacturer, category
        );
    }
}
