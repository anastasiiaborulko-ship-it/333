package com.dmdev.pw2.backend.config;

import com.dmdev.pw2.backend.database.entity.User;
import com.dmdev.pw2.backend.database.repositories.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TempPasswordEncoderRunner implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public TempPasswordEncoderRunner(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        List<User> users = userRepository.findAll();
        for (User user : users) {
            if (user.getPassword() != null && user.getPassword().startsWith("$2a$")) {
                String encoded = passwordEncoder.encode(user.getPassword());
                user.setPassword(encoded);
                userRepository.save(user);
                System.out.println("Encoded password for user: " + user.getEmail());
            }
        }
        System.out.println("Done!");
    }
}
