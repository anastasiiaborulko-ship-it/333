package com.dmdev.pw2.backend.database.repositories;

import com.dmdev.pw2.backend.database.entity.OrderProduct;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderProductRepository extends JpaRepository<OrderProduct, Integer> {
    // TODO: create queries
}
