package com.dmdev.pw2.backend.database.repositories;

import com.dmdev.pw2.backend.database.entity.Role;
import com.dmdev.pw2.backend.database.entity.User;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    @Query("select u from User u where u.phoneNumber = :phoneNumber")
    Optional<User> findByPhoneNumber(@Param("phoneNumber") String phoneNumber);

    @Modifying
    @Transactional
    @Query("update User u set u.name = :firstname, u.surname = :lastname where u.userId = :id")
    int updateUserProfile(@Param("id") Long id,
                          @Param("firstname") String firstname,
                          @Param("lastname") String lastname);

    @Modifying
    @Transactional
    @Query("update User u set u.password = :password where u.userId = :id")
    int updatePassword(@Param("id") Long id, @Param("password") String password);

    @Modifying
    @Transactional
    @Query("update User u set u.role = :role where u.userId = :id")
    int updateRole(@Param("id") Long id, @Param("role") Role role);
}
