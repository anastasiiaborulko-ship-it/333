import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './reusable_components/authentication/login/login.component';
import { RegisterComponent } from './reusable_components/authentication/register/register.component';
import { AdminComponent } from './pages/admin/admin.component';
import { OrderComponent } from './pages/order/order.component';
import { ProductGalleryComponent } from './pages/products/product-gallery.component/product-gallery.component';
import { ProductDetailsComponent } from './pages/products/product-details.component/product-details.component';
import { HomeComponent } from './pages/home/home.component';
import { AdminOrdersComponent } from './pages/admin/admin-orders/admin-orders.component';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'home', component: HomeComponent },
  { path: 'products', component: ProductGalleryComponent },
  { path: 'products/:id', component: ProductDetailsComponent },
  { path: 'order', component: OrderComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'admin/orders', component: AdminOrdersComponent },
  { path: '**', redirectTo: '/login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
