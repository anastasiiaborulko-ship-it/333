package com.dmdev.pw2.backend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
public class OrderResponseDTO {
    private Long orderId;
    private LocalDate orderDate;
    private LocalDate deliveryDate;
    private String orderStatus;
    private BigDecimal totalPrice;
    private List<OrderProductDTO> orderProducts;
}
