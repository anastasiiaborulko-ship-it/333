package com.dmdev.pw2.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pw2Application {

    //to generate db, run this
	public static void main(String[] args) {
		SpringApplication.run(Pw2Application.class, args);
	}

}
