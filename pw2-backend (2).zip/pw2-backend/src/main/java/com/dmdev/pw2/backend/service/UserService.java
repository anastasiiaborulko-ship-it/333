package com.dmdev.pw2.backend.service;

import com.dmdev.pw2.backend.database.entity.User;
import com.dmdev.pw2.backend.database.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public void deleteUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        userRepository.delete(user); //cascades to Orders
    }
}
