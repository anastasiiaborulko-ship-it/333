package com.dmdev.pw2.backend.service;

import com.dmdev.pw2.backend.database.entity.*;
import com.dmdev.pw2.backend.database.repositories.OrdersRepository;
import com.dmdev.pw2.backend.database.repositories.ProductRepository;
import com.dmdev.pw2.backend.database.repositories.UserRepository;
import com.dmdev.pw2.backend.dto.OrderProductDTO;
import com.dmdev.pw2.backend.dto.OrderRequestDTO;
import com.dmdev.pw2.backend.dto.OrderResponseDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrdersService {

    private final OrdersRepository ordersRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    //==================== USER ====================//

    public Orders createOrder(OrderRequestDTO requestDTO) {

        User user = userRepository.findById(requestDTO.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Orders orders = new Orders();
        orders.setUser(user);

        BigDecimal total = BigDecimal.ZERO;

        for (OrderRequestDTO.OrderProductDTO item : requestDTO.getProducts()) {

            Product product = productRepository.findById(item.getProductId())
                    .orElseThrow(() -> new RuntimeException("Product not found"));

            OrderProduct orderProduct = new OrderProduct();
            orderProduct.setOrder(orders);
            orderProduct.setProduct(product);
            orderProduct.setQuantity(item.getQuantity());

            total = total.add(product.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())));

            orders.getOrderProducts().add(orderProduct);
        }

        orders.setTotalPrice(total);
        orders.setOrderStatus(OrderStatus.valueOf("PENDING"));
        orders.setDeliveryDate(LocalDate.now().plusDays(7)); 

        return ordersRepository.save(orders);
    }

    @Transactional(readOnly = true)
    public List<OrderResponseDTO> getOrdersForUser(Long userId) {
        return ordersRepository.findByUser_UserId(userId).stream()
                .map(order -> {
                    List<OrderProductDTO> products = order.getOrderProducts().stream()
                            .map(op -> new OrderProductDTO(
                                    op.getOrderProductId(),
                                    op.getQuantity(),
                                    new OrderProductDTO.ProductInfo(
                                            op.getProduct().getProductId(),
                                            op.getProduct().getName(),
                                            op.getProduct().getPrice()
                                    )
                            ))
                            .collect(Collectors.toList());

                    return new OrderResponseDTO(
                            order.getOrderId(),
                            order.getOrderDate(),
                            order.getDeliveryDate(),
                            order.getOrderStatus().name(),
                            order.getTotalPrice(),
                            products
                    );
                })
                .collect(Collectors.toList());
    }


    public void deleteOrder(Long orderId) {
        Orders order = ordersRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        ordersRepository.delete(order);
    }

    //==================== ADMIN ====================//

    public List<Orders> getAllOrders() {
        return ordersRepository.findAll();
    }

    public Orders updateStatus(Long orderId, String status) {

        List<String> valid = List.of("PENDING", "PROCESSING", "DELIVERED", "CANCELLED");
        if (!valid.contains(status))
            throw new RuntimeException("Invalid status value");

        Orders order = ordersRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        order.setOrderStatus(OrderStatus.valueOf(status));
        return ordersRepository.save(order);
    }

    public OrderResponseDTO mapToDTO(Orders order) {
        List<OrderProductDTO> products = order.getOrderProducts().stream()
                .map(op -> new OrderProductDTO(
                        op.getOrderProductId(),
                        op.getQuantity(),
                        new OrderProductDTO.ProductInfo(
                                op.getProduct().getProductId(),
                                op.getProduct().getName(),
                                op.getProduct().getPrice()
                        )
                ))
                .toList();

        return new OrderResponseDTO(
                order.getOrderId(),
                order.getOrderDate(),
                order.getDeliveryDate(),
                order.getOrderStatus().name(),
                order.getTotalPrice(),
                products
        );
    }

}
