package com.dmdev.pw2.backend.database.repositories;

import com.dmdev.pw2.backend.database.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    @Query("""
            SELECT p FROM Product p
            WHERE (:name IS NULL OR LOWER(p.name) LIKE LOWER(CONCAT('%', :name, '%')))
              AND (:category IS NULL OR LOWER(p.category) = LOWER(:category))
              AND (:colour IS NULL OR LOWER(p.colour) = LOWER(:colour))
              AND (:material IS NULL OR LOWER(p.material) = LOWER(:material))
              AND (:manufacturer IS NULL OR LOWER(p.manufacturer) = LOWER(:manufacturer))
              AND (:minPrice IS NULL OR p.price >= :minPrice)
              AND (:maxPrice IS NULL OR p.price <= :maxPrice)
            """)
    List<Product> searchProducts(
            @Param("name") String name,
            @Param("colour") String colour,
            @Param("minPrice") BigDecimal minPrice,
            @Param("maxPrice") BigDecimal maxPrice,
            @Param("material") String material,
            @Param("manufacturer") String manufacturer,
            @Param("category") String category
    );
}
