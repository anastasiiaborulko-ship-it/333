import { Component } from '@angular/core';
import {Order, OrdersService, OrderStatus} from './order.service';
import {FormsModule} from '@angular/forms';
import {CommonModule, DatePipe, NgClass} from '@angular/common';
import {NavbarComponent} from '../../reusable_components/navbar/navbar.component';
import {FooterComponent} from '../../reusable_components/footer/footer.component';
import {RouterLink} from '@angular/router';

@Component({
  selector: 'app-orders',
  templateUrl: './order.component.html',
  imports: [
    FormsModule,
    DatePipe,
    NgClass,
    NavbarComponent,
    FooterComponent,
    CommonModule,
    RouterLink
  ],
  styleUrls: ['./order.component.css']
})
export class OrderComponent {

  orders: Order[] = [];

  // === Filters ===
  searchText: string = '';
  statusFilter: OrderStatus | '' = '';

  OrderStatus = OrderStatus;

  isLoading = false;
  errorMessage = '';

  constructor(private ordersService: OrdersService) {}

  ngOnInit(): void {
    const storedUser = localStorage.getItem('user');
    const userId = storedUser ? JSON.parse(storedUser).id : null;

    if (!userId) {
      console.error('User not logged in');
      return;
    }

    this.loadOrders(userId);
  }

  loadOrders(userId: number): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.ordersService.getMyOrders(userId).subscribe({
      next: (data) => {
        this.orders = data;
        this.isLoading = false;
      },
      error: (err) => {
        console.error(err);
        this.errorMessage = 'Failed to load orders';
        this.isLoading = false;
      }
    });
  }

  // === Receipt download ===
  generateReceipt(order: Order): void {
    const receiptContent = `
==============================
         ORDER RECEIPT
==============================

Order ID: ${order.orderId}
Order Date: ${order.orderDate}
Delivery Date: ${order.deliveryDate ?? "N/A"}
Status: ${order.orderStatus}

Products:
${order.orderProducts.map(p => ` - ${p.product.name} x${p.quantity} = ${p.product.price * p.quantity}€`).join('\n')}

------------------------------
Total Price: ${order.totalPrice} €
==============================
Thank you for your purchase!
`;

    const blob = new Blob([receiptContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.download = `order_${order.orderId}_receipt.txt`;
    link.click();

    window.URL.revokeObjectURL(url);
  }

  // === Filters Logic ===
  filteredOrders(): Order[] {
    return this.orders.filter(order => {
      const matchesStatus = this.statusFilter ? order.orderStatus === this.statusFilter : true;
      const matchesSearch = this.searchText
        ? order.orderProducts.some(p => p.product.name.toLowerCase().includes(this.searchText.toLowerCase()))
        : true;

      return matchesStatus && matchesSearch;
    });
  }
}
