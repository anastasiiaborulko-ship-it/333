import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {NavbarComponent} from '../../reusable_components/navbar/navbar.component';

interface AdminProduct {
  productId: number;
  name: string;
  category: string;
  material: string;
  colour: string;
  image: string;
  price: number;
  manufacturer: string;
}

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, FormsModule, NavbarComponent],
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent implements OnInit {

  products: AdminProduct[] = [];

  formProduct: Partial<AdminProduct> = {
    name: '',
    category: '',
    material: '',
    colour: '',
    image: '',
    price: 0,
    manufacturer: ''
  };

  editingId: number | null = null;
  isLoading = false;
  errorMessage = '';

  private baseUrl = 'http://localhost:8080/api/admin/products';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts(): void {
    this.isLoading = true;
    this.http.get<AdminProduct[]>(this.baseUrl, { withCredentials : true }).subscribe({
      next: (data) => {
        this.products = data;
        this.isLoading = false;
      },
      error: (err) => {
        console.error(err);
        this.errorMessage = 'Failed to load products';
        this.isLoading = false;
      }
    });
  }

  startEdit(product: AdminProduct): void {
    this.editingId = product.productId;
    this.formProduct = { ...product };
  }

  cancelEdit(): void {
    this.editingId = null;
    this.formProduct = {
      name: '',
      category: '',
      material: '',
      colour: '',
      image: '',
      price: 0,
      manufacturer: ''
    };
  }

  saveProduct(): void {
    if (!this.formProduct.name || !this.formProduct.price) {
      alert('Name and price are required');
      return;
    }

    const body = {
      name: this.formProduct.name,
      category: this.formProduct.category,
      material: this.formProduct.material,
      colour: this.formProduct.colour,
      image: this.formProduct.image,
      price: this.formProduct.price,
      manufacturer: this.formProduct.manufacturer
    };

    if (this.editingId !== null) {
      this.http.put<AdminProduct>(`${this.baseUrl}/${this.editingId}`, body, { withCredentials : true }).subscribe({
        next: () => {
          this.loadProducts();
          this.cancelEdit();
        },
        error: (err) => {
          console.error(err);
          alert('Failed to update product');
        }
      });
    }
    else {
      this.http.post<AdminProduct>(this.baseUrl, body, { withCredentials : true }).subscribe({
        next: () => {
          this.loadProducts();
          this.cancelEdit();
        },
        error: (err) => {
          console.error(err);
          alert('Failed to create product');
        }
      });
    }
  }

  deleteProduct(id: number): void {
    if (!confirm('Delete this product?')) return;

    this.http.delete(`${this.baseUrl}/${id}`, { withCredentials : true }).subscribe({
      next: () => {
        this.products = this.products.filter(p => p.productId !== id);
      },
      error: (err) => {
        console.error(err);
        alert('Failed to delete product');
      }
    });
  }
}
