import { Component, Input, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ProductModel } from '../product.model';
import { ProductService } from '../product.service';
import { CommonModule, NgForOf, NgOptimizedImage } from '@angular/common';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-product-gallery',
  standalone: true,
  imports: [
    RouterLink,
    CommonModule,
    NgForOf,
    FormsModule
  ],
  templateUrl: './product-gallery.component.html',
  styleUrls: ['./product-gallery.component.css'],
})
export class ProductGalleryComponent implements OnInit {

  @Input() searchQuery: string = '';
  @Input() category: string = '';
  @Input() colour: string = '';
  @Input() material: string = '';
  @Input() manufacturer: string = '';

  @Input() products: ProductModel[] | null = null;

  isLoading = false;
  errorMessage = '';

  constructor(private productService: ProductService) {}

  ngOnInit(): void {

    if (this.products && this.products.length > 0) return;

    this.loadProducts();
  }

  loadProducts(): void {
    this.isLoading = true;
    this.errorMessage = '';

    this.productService.searchProducts({
      name: this.searchQuery || undefined,
      category: this.category || undefined,
      colour: this.colour || undefined,
      material: this.material || undefined,
      manufacturer: this.manufacturer || undefined
    }).subscribe({
      next: data => {
        this.products = data;
        this.isLoading = false;
      },
      error: err => {
        console.error(err);
        this.errorMessage = 'Failed to load products';
        this.isLoading = false;
      }
    });
  }
}
