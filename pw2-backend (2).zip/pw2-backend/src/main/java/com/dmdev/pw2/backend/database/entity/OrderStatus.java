package com.dmdev.pw2.backend.database.entity;

public enum OrderStatus {
    DELIVERED,
    PREPARING,
    PENDING,
    IN_DELIVERY
}
