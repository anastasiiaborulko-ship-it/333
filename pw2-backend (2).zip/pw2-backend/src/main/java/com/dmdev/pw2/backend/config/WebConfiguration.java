package com.dmdev.pw2.backend.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class WebConfiguration {

}
