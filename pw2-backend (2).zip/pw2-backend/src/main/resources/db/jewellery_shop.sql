-- drop and recreate database
DROP DATABASE IF EXISTS jewelry_shop_db;
CREATE DATABASE IF NOT EXISTS jewelry_shop_db;
USE jewelry_shop_db;

-- create User table first (parent for Orders)
CREATE TABLE IF NOT EXISTS user (
    user_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    name VARCHAR(50),
    surname VARCHAR(50),
    address VARCHAR(255),
    phone_number VARCHAR(50) UNIQUE,
    role VARCHAR(50)
);

-- create Product table (parent for OrderProduct)
CREATE TABLE IF NOT EXISTS product (
    product_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    category VARCHAR(50),
    material VARCHAR(50),
    colour VARCHAR(50),
    image VARCHAR(255),
    price DECIMAL(10,2),
    manufacturer VARCHAR(100)
);

-- create Orders table (parent for OrderProduct)
CREATE TABLE IF NOT EXISTS `orders` (
    order_id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT,
    total_price DECIMAL(10,2),
    order_date DATETIME,
    delivery_date DATETIME,
    order_status VARCHAR(50),
    FOREIGN KEY (user_id) REFERENCES user(user_id)
);

-- create OrderProduct table last, depends on Product and Orders tables
CREATE TABLE IF NOT EXISTS order_product (
    order_product_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT NOT NULL,
    product_id BIGINT,
    quantity INT,
    FOREIGN KEY (product_id) REFERENCES product (product_id),
    FOREIGN KEY (order_id) REFERENCES `orders` (order_id)
);